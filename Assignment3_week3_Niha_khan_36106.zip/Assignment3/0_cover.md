# Assignment 3: Two Averages, One Argument

**Week 3 • Descriptive analytics**

**Name:** Niha Khan
**ERP ID:** 36106

## What is in this folder, and which task each file covers

| File | Assignment task | What is done there |
|---|---|---|
| `0_cover.md` | Cover | Name, ERP ID and this guide to the folder |
| `1_attempt.md` | 1. THINK | Statistics table (mean, median, first-to-last % change per item); which statistic to report for each item and why; with/without a flagged value for one item and why they differ; draft referee's note with every sentence labelled O, E or C; commit hash |
| `2_work.ipynb` | 1. THINK (statistics) | The code that computes the numbers used in `1_attempt.md`, starting from the cleaned file: mean, median and % change per item, and the with/without flagged-value comparison |
| `3_log_reflection.md` | 2. ASK, 3. CHECK, 5. REFLECT | Interpretation Auditor transcript excerpt; audit table (claim, colour, how checked, accepted or rejected); reflection on where the first draft said more than the data allowed |
| `AI_USE_LOG.md` | Three Gates reminder | Log of where AI was used and how the output was checked |
| `teaching_prices_clean.csv` | Input data | The cleaned teaching file (from Week 2) that `2_work.ipynb` reads |
