

**Name:** Niha Khan  **ERP ID:** 36106

> All figures come from the teaching file , using the cleaned version `teaching_prices_clean.csv`. Every number is computed in `2_work.ipynb`.

## Statistics table (cleaned file)

| Item | Mean | Median | Mean - median | First-to-last change (avg of 2 cities) |
|---|---|---|---|---|
| Oil B | 324.83 | 324.00 | 0.83 | +15.3% |
| Pulse C | 205.91 | 206.00 | -0.09 | +3.1% |
| Staple A | 111.26 | 112.50 | -1.24 | +13.0% |
| Sweetener D | 167.15 | 167.50 | -0.35 | +19.4% |

Per city (first to last valid price): Oil B +15.44% / +15.13%, Pulse C +3.75% / +2.40% (City 2 starts on 8 Jan because its 1 Jan price is blank), Staple A +13.37% / +12.62%, Sweetener D +19.80% / +19.03% (City 1 / City 2).

## Which statistic I would report, and why

- **Oil B, Staple A, Sweetener D, Pulse C (typical level):** the median. After cleaning, mean and median are within 1.24 PKR/kg of each other for every item, so the choice barely matters here, but the median is the safer habit because one bad entry can wreck a mean (see below).
- **"Did the price go up?" (all four items):** neither average answers this. Prices rose steadily through the period, so any whole-period average blends early and late weeks. The first-to-last percentage change answers the question directly.

## With and without a flagged value (Sweetener D)

| | n | Mean | Median |
|---|---|---|---|
| With the 9999 entry | 24 | 576.81 | 167.75 |
| Without it | 23 | 167.15 | 167.50 |
| Difference | | 409.66 | 0.25 |

The mean uses the size of every value, so one entry of 9999 moves it by about 410 PKR/kg. The median only uses the middle of the sorted list, so it moves by 0.25.

## Referee's note (labels: O = observation, E = possible explanation, C = causal claim)

1. **[O]** In the teaching file, Sweetener D rose from 149.0 to 178.5 PKR/kg in City 1 and from 155.0 to 184.5 in City 2 between 1 January and 19 March 2026, about 19 to 20 percent.
2. **[O]** Over the same weeks Oil B rose about 15 percent, Staple A about 13 percent and Pulse C about 2 to 4 percent.
3. **[O]** After cleaning, each item's mean and median differ by at most 1.24 PKR/kg, so for this file the two neighbours' numbers agree closely.
4. **[O]** Before cleaning, a single Sweetener D entry of 9999 pushed that item's mean to 576.81 while its median stayed at 167.75.
5. **[E]** A possible explanation is that 9999 is a placeholder code rather than a real price, since the item's other prices lie between 149.0 and 184.5.
6. **[E]** A possible explanation for the morning argument is that one neighbour is quoting an average contaminated by entries like this, and the other an average that is not.
7. **[O]** Because prices climbed steadily, an average over the whole period describes a typical level, not whether the price rose; the first-to-last change does that.
8. **[E]** My suggested ruling is that the median is the safer figure to quote for a typical price and the percentage change is the right figure for "did it go up", but this is a judgement about which question is being asked, not a statistical fact.

